<p>
	# Attribute-Based-Searchable-Encryption, you can find more details about the schema in https://eprint.iacr.org/2017/782.
</p>
<p>
	<strong>About the import:</strong>
</p>
<p>
	Import the two jars of jpbc-api-1.2.1.jar and jpbc-plaf-1.2.1.jar
</p>
<p>
	<strong>File not found:</strong>
</p>
<p>
	Add the downloaded folder jpbc-1.2.1.zip(must be the .zip folder)&nbsp;into&nbsp;the source.
</p>
