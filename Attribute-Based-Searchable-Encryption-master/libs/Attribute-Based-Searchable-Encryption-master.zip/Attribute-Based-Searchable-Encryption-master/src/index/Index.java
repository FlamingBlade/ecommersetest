package index;

public class Index {
	public String word;
	public String [] file;
	public Index(){
		
	}
	public Index(String word,String []file){
		this.word = word;
		this.file = file;
	}
}
