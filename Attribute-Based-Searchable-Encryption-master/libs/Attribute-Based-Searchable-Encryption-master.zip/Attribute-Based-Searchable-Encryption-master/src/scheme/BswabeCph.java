package scheme;

import it.unisa.dia.gas.jpbc.Element;

public class BswabeCph {
	
	public Element w; /* G_1 */
	public Element w0; /* G_1 */
	public Element u_gate; /* G_1*/
	//public BswabePolicy p;
}
