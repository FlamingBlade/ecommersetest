package scheme;

import it.unisa.dia.gas.jpbc.Element;

public class BswabeMsk {
	/*
	 * A master secret key
	 */
	public Element a,b,c; /* Z_r */
	public Element []r;/*Z_r*/
	public Element []x ;/*G_1*/
	
	
	
	public Element g_alpha; /* G_2 */	
}
