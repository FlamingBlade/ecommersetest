package scheme;

import it.unisa.dia.gas.jpbc.Element;

public class BswabeToken {
	public Element tok1; /* G_2 */
	public Element tok2; /* G_2 */
	public Element tok3; /* G_2 */
	public Element tok4; /* G_2 */
	public Element tok5; /* G_T */
}
